
SMODS.Booster {
    key = 'purple_pack',
    loc_txt = {
        name = "Purple Pack",
        text = {
            [1] = 'Choose {C:attention}1{} of {C:attention}6{} Powerful Joker Cards.'
        },
        group_name = "toomuchs_boosters"
    },
    config = { extra = 6, choose = 1 },
    cost = 15,
    weight = 0.2,
    atlas = "CustomBoosters",
    pos = { x = 0, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        local weights = {
            0.15,
            1.1
        }
        local total_weight = 0
        for _, weight in ipairs(weights) do
            total_weight = total_weight + weight
        end
        local random_value = pseudorandom('toomuchs_purple_pack_card') * total_weight
        local cumulative_weight = 0
        local selected_index = 1
        for j, weight in ipairs(weights) do
            cumulative_weight = cumulative_weight + weight
            if random_value <= cumulative_weight then
                selected_index = j
                break
            end
        end
        if selected_index == 1 then
            return {
                set = "Joker",
                rarity = "Legendary",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "toomuchs_purple_pack"
            }
        elseif selected_index == 2 then
            return {
                set = "Joker",
                rarity = "toomuchs_rare4me",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "toomuchs_purple_pack"
            }
        end
    end,
    particles = function(self)
        -- No particles for joker packs
        end,
    }
    