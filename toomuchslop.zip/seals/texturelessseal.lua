
SMODS.Seal {
    key = 'texturelessseal',
    pos = { x = 0, y = 0 },
    badge_colour = HEX('000000'),
    loc_txt = {
        name = 'Textureless Seal',
        label = 'Textureless Seal',
        text = {
            [1] = 'If the hand this card is discarded in is a {C:attention}Pair{},',
            [2] = 'replace this seal with another random seal.'
        }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.discard and context.other_card == card then
            return {
                func = function()
                    local random_seal = SMODS.poll_seal({mod = 10})
                    if random_seal then
                        context.other_card:set_seal(random_seal, true)
                    end
                end,
                message = "Card Modified!"
            }
        end
    end
}