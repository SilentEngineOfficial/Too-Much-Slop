SMODS.Atlas({
    key = "modicon", 
    path = "ModIcon.png", 
    px = 34,
    py = 34,
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "balatro", 
    path = "balatro.png", 
    px = 333,
    py = 216,
    prefix_config = { key = false },
    atlas_table = "ASSET_ATLAS"
})


SMODS.Atlas({
    key = "CustomJokers", 
    path = "CustomJokers.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomConsumables", 
    path = "CustomConsumables.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomBoosters", 
    path = "CustomBoosters.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomSeals", 
    path = "CustomSeals.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
}):register()

SMODS.Atlas({
    key = "CustomDecks", 
    path = "CustomDecks.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

local NFS = require("nativefs")
to_big = to_big or function(a) return a end
lenient_bignum = lenient_bignum or function(a) return a end
-- this function is used to load everything within a folder.-- Jokerforge doesnt use it because it doesnt make loading order easy
local function load_folder(path)
    local files = NFS.getDirectoryItemsInfo(mod_path .. "/" .. path)
    for i = 1, #files do
        local file_name = files[i].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file(path .. file_name))()
        end
    end
end
-- load the jokers
if true then
    assert(SMODS.load_file("jokers/whoyoutagginggng.lua"))()
    assert(SMODS.load_file("jokers/yisang.lua"))()
    assert(SMODS.load_file("jokers/gregorsamsa.lua"))()
    assert(SMODS.load_file("jokers/_4dabloons.lua"))()
    assert(SMODS.load_file("jokers/coalalert.lua"))()
    assert(SMODS.load_file("jokers/chudjak.lua"))()
    assert(SMODS.load_file("jokers/ishowjoy.lua"))()
    assert(SMODS.load_file("jokers/allears.lua"))()
    assert(SMODS.load_file("jokers/royalvictoriaplace.lua"))()
    assert(SMODS.load_file("jokers/heatcheque.lua"))()
    assert(SMODS.load_file("jokers/artwork.lua"))()
    assert(SMODS.load_file("jokers/thosewho.lua"))()
    assert(SMODS.load_file("jokers/chooseyourfate.lua"))()
    assert(SMODS.load_file("jokers/despair.lua"))()
    assert(SMODS.load_file("jokers/miyamotomusashi.lua"))()
    assert(SMODS.load_file("jokers/literalpileofchips.lua"))()
    assert(SMODS.load_file("jokers/yaman.lua"))()
    assert(SMODS.load_file("jokers/idfsoldiers.lua"))()
    assert(SMODS.load_file("jokers/thebigbag.lua"))()
    assert(SMODS.load_file("jokers/enormousdumpster.lua"))()
    assert(SMODS.load_file("jokers/themultmug.lua"))()
    assert(SMODS.load_file("jokers/adamrose.lua"))()
    assert(SMODS.load_file("jokers/interruption.lua"))()
    assert(SMODS.load_file("jokers/arbystakeover.lua"))()
    assert(SMODS.load_file("jokers/josephjoestar.lua"))()
    assert(SMODS.load_file("jokers/bloke.lua"))()
    assert(SMODS.load_file("jokers/pureaura.lua"))()
    assert(SMODS.load_file("jokers/goodanswernephew.lua"))()
    assert(SMODS.load_file("jokers/nostalgicinterruption.lua"))()
    assert(SMODS.load_file("jokers/airwaves.lua"))()
    assert(SMODS.load_file("jokers/thragg.lua"))()
    assert(SMODS.load_file("jokers/iamiceman.lua"))()
    assert(SMODS.load_file("jokers/aeternus.lua"))()
    assert(SMODS.load_file("jokers/ajoker.lua"))()
end
-- load the consumables
if true then
    assert(SMODS.load_file("consumables/wheelofsomething.lua"))()
    assert(SMODS.load_file("consumables/wheelofweakening.lua"))()
    assert(SMODS.load_file("consumables/dicevoucher.lua"))()
end
-- load the seals
if true then
    assert(SMODS.load_file("seals/texturelessseal.lua"))()
end

-- load the decks
if true then
    assert(SMODS.load_file("decks/ice_deck.lua"))()
    assert(SMODS.load_file("decks/aeternum_deck.lua"))()
end



assert(SMODS.load_file("rarities.lua"))()


-- load boosters
assert(SMODS.load_file("boosters.lua"))()
SMODS.ObjectType({
    key = "toomuchs_food",
    cards = {
        ["j_gros_michel"] = true,
        ["j_egg"] = true,
        ["j_ice_cream"] = true,
        ["j_cavendish"] = true,
        ["j_turtle_bean"] = true,
        ["j_diet_cola"] = true,
        ["j_popcorn"] = true,
        ["j_ramen"] = true,
        ["j_selzer"] = true
    },
})

SMODS.ObjectType({
    key = "toomuchs_toomuchs_jokers",
    cards = {
        ["j_toomuchs_whoyoutagginggng"] = true,
        ["j_toomuchs_gregorsamsa"] = true,
        ["j_toomuchs__4dabloons"] = true,
        ["j_toomuchs_coalalert"] = true,
        ["j_toomuchs_chudjak"] = true,
        ["j_toomuchs_ishowjoy"] = true,
        ["j_toomuchs_allears"] = true,
        ["j_toomuchs_royalvictoriaplace"] = true,
        ["j_toomuchs_heatcheque"] = true,
        ["j_toomuchs_artwork"] = true,
        ["j_toomuchs_chooseyourfate"] = true,
        ["j_toomuchs_despair"] = true,
        ["j_toomuchs_miyamotomusashi"] = true,
        ["j_toomuchs_literalpileofchips"] = true,
        ["j_toomuchs_yaman"] = true,
        ["j_toomuchs_idfsoldiers"] = true,
        ["j_toomuchs_thebigbag"] = true,
        ["j_toomuchs_enormousdumpster"] = true,
        ["j_toomuchs_themultmug"] = true,
        ["j_toomuchs_adamrose"] = true,
        ["j_toomuchs_interruption"] = true,
        ["j_toomuchs_arbystakeover"] = true,
        ["j_toomuchs_josephjoestar"] = true,
        ["j_toomuchs_bloke"] = true,
        ["j_toomuchs_pureaura"] = true,
        ["j_toomuchs_goodanswernephew"] = true,
        ["j_toomuchs_nostalgicinterruption"] = true,
        ["j_toomuchs_airwaves"] = true,
        ["j_toomuchs_thragg"] = true,
        ["j_toomuchs_iamiceman"] = true,
        ["j_toomuchs_aeternus"] = true,
        ["j_toomuchs_ajoker"] = true
    },
})

SMODS.ObjectType({
    key = "toomuchs_mycustom_jokers",
    cards = {
        ["j_toomuchs_thosewho"] = true
    },
})

SMODS.ObjectType({
    key = "toomuchs_iceman",
    cards = {
        ["j_toomuchs_iamiceman"] = true
    },
})


SMODS.current_mod.optional_features = function()
    return {
        cardareas = {} 
    }
end