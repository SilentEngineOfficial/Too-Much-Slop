
SMODS.Joker{ --Heat Cheque
    key = "heatcheque",
    config = {
        extra = {
            flightxmult = 1
        }
    },
    loc_txt = {
        ['name'] = 'Heat Cheque',
        ['text'] = {
            [1] = 'This Joker gains {X:mult,C:white}X0.1{} Mult if played',
            [2] = 'hand is your {C:attention}most played hand{} {C:inactive}(Currently{} {X:mult,C:white} #1#{}{C:inactive} Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 9,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["toomuchs_toomuchs_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.flightxmult}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
                local current_played = G.GAME.hands[context.scoring_name].played or 0
                for handname, values in pairs(G.GAME.hands) do
                    if handname ~= context.scoring_name and values.played > current_played and values.visible then
                        return false
                    end
                end
                return true
            end)() then
                card.ability.extra.flightxmult = (card.ability.extra.flightxmult) + 0.1
            else
                return {
                    Xmult = card.ability.extra.flightxmult
                }
            end
        end
    end
}