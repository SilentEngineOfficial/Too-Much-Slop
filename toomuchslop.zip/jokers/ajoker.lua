
SMODS.Joker{ --A Joker
    key = "ajoker",
    config = {
        extra = {
            levels0 = 2
        }
    },
    loc_txt = {
        ['name'] = 'A Joker',
        ['text'] = {
            [1] = '{C:dark_edition}+2 levels{} after hand is played.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = "toomuchs_thisthemostoverpoweredraritywhatitdoesisthatit",
    blueprint_compat = false,
    eternal_compat = false,
    perishable_compat = false,
    unlocked = false,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["toomuchs_toomuchs_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' 
            or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  and not context.blueprint then
            local target_hand = (context.scoring_name or "High Card")
            level_up_hand(card, target_hand, true, 2)
            return {
                message = localize('k_level_up_ex')
            }
        end
    end
}