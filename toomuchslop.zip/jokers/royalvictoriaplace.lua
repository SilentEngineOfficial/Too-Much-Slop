
SMODS.Joker{ --Royal Victoria Place
    key = "royalvictoriaplace",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Royal Victoria Place',
        ['text'] = {
            [1] = '{C:attention}+1{} Joker Slot',
            [2] = 'Royal Victoria Place is a British, partially',
            [3] = 'covered shopping centre in Tunbridge Wells, Kent.',
            [4] = 'In 2019, it contained 99 retail units, as well as the Camden Centre,',
            [5] = 'a community facility managed by Tunbridge Wells Borough Council.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 1,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["toomuchs_toomuchs_jokers"] = true },
    
    calculate = function(self, card, context)
    end,
    
    add_to_deck = function(self, card, from_debuff)
        G.jokers.config.card_limit = G.jokers.config.card_limit + 1
    end,
    
    remove_from_deck = function(self, card, from_debuff)
        G.jokers.config.card_limit = G.jokers.config.card_limit - 1
    end
}

local check_for_buy_space_ref = G.FUNCS.check_for_buy_space
G.FUNCS.check_for_buy_space = function(card)
    if card.config.center.key == "j_toomuchs_royalvictoriaplace" then -- ignore slot limit when bought
        return true
    end
    return check_for_buy_space_ref(card)
end

local can_select_card_ref = G.FUNCS.can_select_card
G.FUNCS.can_select_card = function(e)
    	if e.config.ref_table.config.center.key == "j_toomuchs_royalvictoriaplace" then
        		e.config.colour = G.C.GREEN
        		e.config.button = "use_card"
    	else
        		can_select_card_ref(e)
    	end
end