
SMODS.Joker{ --Aeternus
    key = "aeternus",
    config = {
        extra = {
            aeternusexpomult = 1
        }
    },
    loc_txt = {
        ['name'] = 'Aeternus',
        ['text'] = {
            [1] = 'This Joker gains {X:edition,C:white}^0.03{} Mult if played',
            [2] = 'hand contains a {C:attention}Three Of A Kind{} made of {C:attention}6s{}',
            [3] = '{C:inactive}(Currently{} {X:edition,C:white}^#1#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    dependencies = {"Cryptid"},
    pools = { ["toomuchs_toomuchs_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' and args.source ~= 'jud' 
            or args.source == 'buf' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.aeternusexpomult}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (next(context.poker_hands["Three of a Kind"]) and (function()
                local count = 0
                for _, playing_card in pairs(context.scoring_hand or {}) do
                    if playing_card:get_id() == 6 then
                        count = count + 1
                    end
                end
                return count >= 3
            end)()) then
                card.ability.extra.aeternusexpomult = (card.ability.extra.aeternusexpomult) + 0.03
            else
                return {
                    e_mult = card.ability.extra.aeternusexpomult
                }
            end
        end
    end
}