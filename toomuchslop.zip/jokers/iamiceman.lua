
SMODS.Joker{ --I AM ICEMAN
    key = "iamiceman",
    config = {
        extra = {
            Icemanchips = 1
        }
    },
    loc_txt = {
        ['name'] = 'I AM ICEMAN',
        ['text'] = {
            [1] = 'This Joker gains {X:chips,C:white}X1{} Chips for every hand',
            [2] = 'played using at least 5 {C:attention}bonus cards{}.',
            [3] = '{C:inactive}(Currently{} {X:chips,C:white}X#1#{} {C:inactive}Chips){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["toomuchs_toomuchs_jokers"] = true, ["toomuchs_iceman"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' 
            or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.Icemanchips}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            card.ability.extra.Icemanchips = (card.ability.extra.Icemanchips) + 1
            return {
                x_chips = card.ability.extra.Icemanchips
            }
        end
    end
}