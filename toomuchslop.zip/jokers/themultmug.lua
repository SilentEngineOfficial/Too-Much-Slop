
SMODS.Joker{ --The Mult Mug
    key = "themultmug",
    config = {
        extra = {
            xmult0_min = NaN,
            xmult0_max = 4
        }
    },
    loc_txt = {
        ['name'] = 'The Mult Mug',
        ['text'] = {
            [1] = 'Gives {X:mult,C:white}X2 - X4{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["toomuchs_toomuchs_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = pseudorandom('RANGE:2|4', 2, 4)
            }
        end
    end
}