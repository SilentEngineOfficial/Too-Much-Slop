
SMODS.Joker{ --Good Answer Nephew
    key = "goodanswernephew",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Good Answer Nephew',
        ['text'] = {
            [1] = 'At the end of the {C:attention}round{}, if remaining hands >2 and discards are',
            [2] = '>1, create a {C:attention}Handy Tag{}.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 14,
    rarity = "toomuchs_rare4me",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["toomuchs_toomuchs_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
            if (to_big(G.GAME.current_round.hands_left) > to_big(2) and to_big(G.GAME.current_round.discards_left) > to_big(1)) then
                return {
                    func = function()
                        G.E_MANAGER:add_event(Event({
                            func = function()
                                local tag = Tag("tag_handy")
                                if tag.name == "Orbital Tag" then
                                    local _poker_hands = {}
                                    for k, v in pairs(G.GAME.hands) do
                                        if v.visible then
                                            _poker_hands[#_poker_hands + 1] = k
                                        end
                                    end
                                    tag.ability.orbital_hand = pseudorandom_element(_poker_hands, "jokerforge_orbital")
                                end
                                tag:set_ability()
                                add_tag(tag)
                                play_sound('holo1', 1.2 + math.random() * 0.1, 0.4)
                                return true
                            end
                        }))
                        return true
                    end,
                    message = "Created Tag!"
                }
            end
        end
    end
}