
SMODS.Joker{ --Miyamoto Musashi
    key = "miyamotomusashi",
    config = {
        extra = {
            musashixmult = 1,
            blind_size0 = 0.75
        }
    },
    loc_txt = {
        ['name'] = 'Miyamoto Musashi',
        ['text'] = {
            [1] = '{X:attention,C:white}-25%{} Blind Requirements.',
            [2] = 'This Joker gains {X:mult,C:white}X0.25{} Mult if played hand',
            [3] = 'contains a {C:attention}Four of a kind{}',
            [4] = '{C:inactive}(Currently{} {X:mult,C:white}X#1#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["toomuchs_toomuchs_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.musashixmult}}
    end,
    
    calculate = function(self, card, context)
        if context.setting_blind  then
            return {
                
                func = function()
                    if G.GAME.blind.in_blind then
                        
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "X"..tostring(0.75).." Blind Size", colour = G.C.GREEN})
                        G.GAME.blind.chips = G.GAME.blind.chips * 0.75
                        G.GAME.blind.chip_text = number_format(G.GAME.blind.chips)
                        G.HUD_blind:recalculate()
                        return true
                    end
                end
            }
        end
        if context.cardarea == G.jokers and context.joker_main  then
            if next(context.poker_hands["Four of a Kind"]) then
                card.ability.extra.musashixmult = (card.ability.extra.musashixmult) + 0.25
            else
                return {
                    Xmult = card.ability.extra.musashixmult
                }
            end
        end
    end
}