
SMODS.Joker{ --Enormous Dumpster
    key = "enormousdumpster",
    config = {
        extra = {
            discards_change = '3'
        }
    },
    loc_txt = {
        ['name'] = 'Enormous Dumpster',
        ['text'] = {
            [1] = '{C:red}+3{} Discards, {C:red}-1{} Joker Slot.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 1
    },
    display_size = {
        w = 71 * 2, 
        h = 95 * 1
    },
    cost = 11,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["toomuchs_toomuchs_jokers"] = true },
    
    calculate = function(self, card, context)
    end,
    
    add_to_deck = function(self, card, from_debuff)
        G.GAME.round_resets.discards = G.GAME.round_resets.discards + 3
        G.jokers.config.card_limit = math.max(1, G.jokers.config.card_limit - 1)
    end,
    
    remove_from_deck = function(self, card, from_debuff)
        G.GAME.round_resets.discards = G.GAME.round_resets.discards - 3
        G.jokers.config.card_limit = G.jokers.config.card_limit + 1
    end
}