
SMODS.Joker{ --Joseph Joestar
    key = "josephjoestar",
    config = {
        extra = {
            hands0 = 2
        }
    },
    loc_txt = {
        ['name'] = 'Joseph Joestar',
        ['text'] = {
            [1] = 'When {C:attention}boss blind{} is selected, Gain {C:blue}+2 hands{} for',
            [2] = 'the duration of that blind.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 10,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["toomuchs_toomuchs_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.setting_blind  then
            if G.GAME.blind.boss then
                return {
                    
                    func = function()
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(2).." Hands", colour = G.C.GREEN})
                        
                        G.GAME.current_round.hands_left = G.GAME.current_round.hands_left + 2
                        return true
                    end
                }
            end
        end
    end
}