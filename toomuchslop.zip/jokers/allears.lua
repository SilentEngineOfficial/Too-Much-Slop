
SMODS.Joker{ --All Ears
    key = "allears",
    config = {
        extra = {
            AllEarsMult = 0
        }
    },
    loc_txt = {
        ['name'] = 'All Ears',
        ['text'] = {
            [1] = 'This joker gains {C:red}+2{} Mult if played hand',
            [2] = 'contains a {C:attention}Straight{}',
            [3] = '{C:inactive}(Currently{} {C:red}+#1#{} {C:inactive}mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["toomuchs_toomuchs_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.AllEarsMult}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                mult = card.ability.extra.AllEarsMult
            }
        end
        if context.before and context.cardarea == G.jokers  then
            if next(context.poker_hands["Straight"]) then
                return {
                    func = function()
                        card.ability.extra.AllEarsMult = (card.ability.extra.AllEarsMult) + 2
                        return true
                    end
                }
            end
        end
    end
}