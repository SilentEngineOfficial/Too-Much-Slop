
SMODS.Joker{ --Adam Rose
    key = "adamrose",
    config = {
        extra = {
            mult0 = 3
        }
    },
    loc_txt = {
        ['name'] = 'Adam Rose',
        ['text'] = {
            [1] = 'Played Cards give {C:red}+3{} Mult.',
            [2] = '{C:inactive}If you mash strawberries...{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["toomuchs_toomuchs_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            return {
                mult = 3
            }
        end
    end
}