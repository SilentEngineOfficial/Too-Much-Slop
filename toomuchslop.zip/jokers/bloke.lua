
SMODS.Joker{ --Bloke
    key = "bloke",
    config = {
        extra = {
            pluschipsbloke = 0
        }
    },
    loc_txt = {
        ['name'] = 'Bloke',
        ['text'] = {
            [1] = 'Gains {C:blue}+60 Crisps{} every instance of',
            [2] = 'playing cards being destroyed.',
            [3] = '{C:inactive}(Currently{} {C:blue}+#1#{} {C:inactive}Crisps){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 3,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["toomuchs_toomuchs_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.pluschipsbloke}}
    end,
    
    calculate = function(self, card, context)
        if context.remove_playing_cards  then
            return {
                func = function()
                    card.ability.extra.pluschipsbloke = (card.ability.extra.pluschipsbloke) + 60
                    return true
                end
            }
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                chips = card.ability.extra.pluschipsbloke
            }
        end
    end
}