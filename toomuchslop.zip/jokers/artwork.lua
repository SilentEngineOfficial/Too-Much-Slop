
SMODS.Joker{ --Artwork
    key = "artwork",
    config = {
        extra = {
            sell_value0_min = NaN,
            sell_value0_max = 8
        }
    },
    loc_txt = {
        ['name'] = 'Artwork',
        ['text'] = {
            [1] = 'At the end of the round, increase this joker\'s',
            [2] = '{C:money}Sell Value{} by {C:money}$4 - $8{}.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["toomuchs_toomuchs_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
            return {
                func = function()local my_pos = nil
                    for i = 1, #G.jokers.cards do
                        if G.jokers.cards[i] == card then
                            my_pos = i
                            break
                        end
                    end
                    local target_card = G.jokers.cards[my_pos]
                    target_card.ability.extra_value = (card.ability.extra_value or 0) + pseudorandom('RANGE:4|8', 4, 8)
                    target_card:set_cost()
                    return true
                end,
                message = "+"..tostring(pseudorandom('RANGE:4|8', 4, 8)).." Sell Value"
            }
        end
    end
}