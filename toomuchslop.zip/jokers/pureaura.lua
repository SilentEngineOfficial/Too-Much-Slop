
SMODS.Joker{ --Pure Aura
    key = "pureaura",
    config = {
        extra = {
            play_size_increase = '1',
            discard_size_increase = '1',
            pureauramult = 1
        }
    },
    loc_txt = {
        ['name'] = 'Pure Aura',
        ['text'] = {
            [1] = 'This Joker gains {X:red,C:white}X0.5{} Mult',
            [2] = 'when played hand contains a',
            [3] = '{C:attention}Straight Flush{}',
            [4] = '{C:inactive}(Currently{} {X:red,C:white}X#1#{} {C:inactive}Mult){}',
            [5] = 'Gives {C:attention}+1 card selection limit{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 17,
    rarity = "toomuchs_rare4me",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["toomuchs_toomuchs_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.pureauramult}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if next(context.poker_hands["Straight Flush"]) then
                card.ability.extra.pureauramult = (card.ability.extra.pureauramult) + 0.5
            else
                return {
                    Xmult = card.ability.extra.pureauramult
                }
            end
        end
    end,
    
    add_to_deck = function(self, card, from_debuff)
        SMODS.change_play_limit(1)
        SMODS.change_discard_limit(1)
    end,
    
    remove_from_deck = function(self, card, from_debuff)
        SMODS.change_play_limit(-1)
        SMODS.change_discard_limit(-1)
    end
}