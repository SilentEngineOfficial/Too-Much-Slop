
SMODS.Joker{ --Thragg
    key = "thragg",
    config = {
        extra = {
            Xmultthragg = 1
        }
    },
    loc_txt = {
        ['name'] = 'Thragg',
        ['text'] = {
            [1] = 'Gains {X:mult,C:white}X0.5{} Mult for every discarded hand',
            [2] = 'containing at least 3 {C:spades}spades{}.',
            [3] = '{C:inactive}(Currently{} {X:red,C:white}X#1#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["toomuchs_toomuchs_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' and args.source ~= 'buf' and args.source ~= 'jud' 
            or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.Xmultthragg}}
    end,
    
    calculate = function(self, card, context)
        if context.pre_discard  then
            if (function()
                local suitCount = 0
                for i, c in ipairs(context.full_hand) do
                    if c:is_suit("Spades") then
                        suitCount = suitCount + 1
                    end
                end
                
                return suitCount >= 3
            end)() then
                return {
                    func = function()
                        card.ability.extra.Xmultthragg = (card.ability.extra.Xmultthragg) + 0.5
                        return true
                    end
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = card.ability.extra.Xmultthragg
            }
        end
    end
}