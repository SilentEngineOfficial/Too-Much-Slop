
SMODS.Joker{ --LITERAL PILE OF CHIPS
    key = "literalpileofchips",
    config = {
        extra = {
            chips0_min = NaN,
            chips0_max = 150
        }
    },
    loc_txt = {
        ['name'] = 'LITERAL PILE OF CHIPS',
        ['text'] = {
            [1] = 'Gives {C:blue}+25 - +150{} Chips.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["toomuchs_toomuchs_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                chips = pseudorandom('RANGE:25|150', 25, 150)
            }
        end
    end
}