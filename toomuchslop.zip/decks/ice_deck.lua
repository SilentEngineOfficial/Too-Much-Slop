
SMODS.Back {
    key = 'ice_deck',
    pos = { x = 0, y = 0 },
    config = {
        extra = {
            booster_slots0 = 1
        },
    },
    loc_txt = {
        name = 'Ice Deck',
        text = {
            [1] = 'Start with 3 {C:dark_edition}negative{} copies',
            [2] = 'of {C:attention}The Heirophant.{}',
            [3] = '{C:attention}+1{} Booster Slot.'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        for i = 1, 3 do
            G.E_MANAGER:add_event(Event({
                func = function()
                    if G.consumeables.config.card_limit > #G.consumeables.cards + G.GAME.consumeable_buffer then
                        G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                    end
                    
                    
                    play_sound('timpani')
                    SMODS.add_card({ set = 'Tarot', edition = 'e_negative', key = 'c_heirophant'
                    })
                    return true
                end
            }))
        end
        return {
            
            G.E_MANAGER:add_event(Event({
                func = function()
                    
                    
                    SMODS.change_booster_limit(1)
                    return true
                end
            }))
        }
    end
}