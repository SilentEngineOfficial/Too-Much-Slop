SMODS.Rarity {
    key = "rare4me",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.024,
    badge_colour = HEX('700e0e'),
    loc_txt = {
        name = "2Rare4Me"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "thisthemostoverpoweredraritywhatitdoesisthatit",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.004,
    badge_colour = HEX('a9ffff'),
    loc_txt = {
        name = "thisthemostoverpoweredraritywhatitdoesisthatit"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}