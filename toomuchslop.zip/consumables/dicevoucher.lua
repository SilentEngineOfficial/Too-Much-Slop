
SMODS.Consumable {
    key = 'dicevoucher',
    set = 'Spectral',
    pos = { x = 2, y = 0 },
    loc_txt = {
        name = 'Dice Voucher',
        text = {
            [1] = 'Redeems a random {C:attention}Voucher{} when used.'
        }
    },
    cost = 7,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
        local voucher_key = pseudorandom_element(G.P_CENTER_POOLS.Voucher, "75842877").key
        local voucher_card = SMODS.create_card{area = G.play, key = voucher_key}
        voucher_card:start_materialize()
        voucher_card.cost = 0
        G.play:emplace(voucher_card)
        delay(0.8)
        voucher_card:redeem()
        
        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.5,
            func = function()
                voucher_card:start_dissolve()                
                return true
            end
        }))
        return {
            message = nil
        }
    end,
    can_use = function(self, card)
        return true
    end
}