
SMODS.Consumable {
    key = 'wheelofsomething',
    set = 'Tarot',
    pos = { x = 0, y = 0 },
    config = { 
        extra = {
            odds = 4   
        } 
    },
    loc_txt = {
        name = 'Wheel Of Something',
        text = {
            [1] = '{C:green}1 in 4{} chance to create a random consumable.'
        }
    },
    cost = 3,
    unlocked = false,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
        if SMODS.pseudorandom_probability(card, 'group_0_782d1b00', 1, card.ability.extra.odds, 'j_toomuchs_wheelofsomething', false) then
            for i = 1, math.min(1, G.consumeables.config.card_limit - #G.consumeables.cards) do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.4,
                    func = function()
                        
                        play_sound('timpani')
                        local sets = {'Tarot', 'Planet', 'Spectral'}
                        local random_set = pseudorandom_element(sets, 'random_consumable_set')
                        SMODS.add_card({ set = random_set, })                            
                        used_card:juice_up(0.3, 0.5)
                        return true
                    end
                }))
            end
            delay(0.6)
            
            if created_consumable then
                card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = localize('k_plus_consumable'), colour = G.C.PURPLE})
            end
            return true
            
        end
    end,
    can_use = function(self, card)
        return true
    end
}