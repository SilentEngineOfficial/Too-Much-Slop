
SMODS.Consumable {
    key = 'wheelofweakening',
    set = 'Tarot',
    pos = { x = 1, y = 0 },
    config = { 
        extra = {
            odds = 10,
            blind_size0 = 2   
        } 
    },
    loc_txt = {
        name = 'Wheel Of Weakening',
        text = {
            [1] = '{C:red}Fixed{} {C:green}1 in 10{} chance to halve current blind requirements.'
        }
    },
    cost = 3,
    unlocked = false,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
        if SMODS.pseudorandom_probability(card, 'group_0_782d1b00', 1, card.ability.extra.odds, 'j_toomuchs_wheelofweakening', true) then
            SMODS.calculate_effect({
                func = function()
                    if G.GAME.blind.in_blind then
                        
                        card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "/"..tostring(2).." Blind Size", colour = G.C.GREEN})
                        G.GAME.blind.chips = G.GAME.blind.chips / 2
                        G.GAME.blind.chip_text = number_format(G.GAME.blind.chips)
                        G.HUD_blind:recalculate()
                        return true
                    end
                end}, card)
            end
        end,
        can_use = function(self, card)
            return true
        end
    }